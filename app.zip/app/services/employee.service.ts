import { Injectable } from '@angular/core';
import { Observable } from 'rxjs/Observable';
import { Http } from '@angular/http';
import 'rxjs/add/operator/map';
@Injectable()
export class EmployeeService {
 // employees:string[];
 data:Observable<Array<String>>;
  constructor(public http:Http) {
   // this.employees = ['ahmed', 'mohammed', 'ali', 'baqir'];
   
    
   }

   getEmpolyees2(){
    return this.http.get('https://jsonplaceholder.typicode.com/users').map(res => res.json());
   }

   getEmpolyees(){
    // this.data = new Observable(observer =>{

    //   setTimeout(() => {
    //     observer.next('ali');
    //   }, 2000);

    //   setTimeout(() => {
    //     observer.next('ahmed');
    //   }, 5000);
     
    // });
    //  return this.data;
   }

}
