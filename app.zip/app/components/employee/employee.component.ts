import { Component, OnInit } from '@angular/core';
import { EmployeeService } from '../../services/employee.service';

@Component({
  selector: 'app-employee',
  templateUrl: './employee.component.html',
  styleUrls: ['./employee.component.css']
})
export class EmployeeComponent implements OnInit {
employees:any[]=[];
  constructor(public employeeServices:EmployeeService) {
    //this.employees = this.employeeServices.getEmpolyees();

    this.employeeServices.getEmpolyees2().subscribe(employees => {
      this.employees = employees;
    });
   }

  ngOnInit() {
  }

}
